import axios from 'axios';

const EMPLOYEE_API_BASE_URL = "http://localhost:9094/employee-db-api";
const EMPLOYEE_API_URL = "http://localhost:8081/employee/findAll";

class EmployeeService{

    getEmployees(){
        return axios.get(EMPLOYEE_API_URL);
       }

       createEmployee(employee){
           console.log("url "+EMPLOYEE_API_BASE_URL +"/addEmployee");
           return axios.post(EMPLOYEE_API_BASE_URL +"/addEmployee", employee);
       }

       getEmployeeById(employeeId){
        console.log("url"+ EMPLOYEE_API_BASE_URL + '/' + employeeId);
        return axios.get(EMPLOYEE_API_BASE_URL + '/' + employeeId);
    }

    updateEmployee(employee, employeeId){
        return axios.put(EMPLOYEE_API_BASE_URL + '/' + employeeId, employee);
    }

    deleteEmployee(employeeId){
        return axios.delete(EMPLOYEE_API_BASE_URL + '/' + employeeId);
    }



}

export default new EmployeeService();