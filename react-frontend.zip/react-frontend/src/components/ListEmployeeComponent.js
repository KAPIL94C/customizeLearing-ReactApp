/* eslint-disable no-template-curly-in-string */
import React, { Component } from 'react';
import EmployeeService from '../services/EmployeeService';

class ListEmployeeComponent extends Component {
    constructor(props){
       super(props)

       this.state = {
           employees :[]
        }
        this.addEmployee = this.addEmployee.bind(this);
        this.editEmployee = this.editEmployee.bind(this);
        this.deleteEmployee = this.deleteEmployee.bind(this);
    }

    deleteEmployee(id){
        EmployeeService.deleteEmployee(id).then( res => {
            this.setState({employees: this.state.employees.filter(employee => employee.eid !== id)});
        });

    }
    viewEmployee(id){
        this.props.history.push(`/view-employee/${id}`) 
    }


    editEmployee(id){
        this.props.history.push(`/add-employee/${id}`) 
    }

   
    componentDidMount(){
        EmployeeService.getEmployees().then((res)=>{
            this.setState({employees: res.data});

        });
    }
    

    addEmployee(){
        this.props.history.push('/add-employee/_add');
    }

    render() {
        return (
            <div>
                <h2 className="text-center"> List Employee </h2>
                <div className="row">
                    <button className="btn btn-primary" onClick={this.addEmployee}>Add Employee</button>

                </div>
                <div className="row" >
                    <table className="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>EmpId</th>
                                <th>Employee Name</th>
                                <th>Employee Designation</th>
                                <th>Actions</th>
                                </tr>
                        </thead>
                        <tbody>{
                            this.state.employees.map(
                                employee => 
                                <tr key={employee.eid}>
                                    <td>{employee.eid}</td>
                                    <td>{employee.name}</td>
                                    <td>{employee.designation}</td>
                                    <td>
                                        <button onClick={()=>this.editEmployee(employee.eid)} className="btn btn-info" >Upade</button>
                                        <button style={{marginLeft:"10px"}} onClick={()=>this.deleteEmployee(employee.eid)} className="btn btn-danger" >Delete</button>
                                        <button style={{marginLeft:"10px"}} onClick={()=>this.viewEmployee(employee.eid)} className="btn btn-info" >View</button>
                                    </td>
                                </tr>
                            ) }
                        </tbody>

                    </table>
                </div>
                
            </div>
        );
    }
}

export default ListEmployeeComponent;